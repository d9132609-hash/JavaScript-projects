let musices = [
  {
    name: "محسن چاوشی - یا مولا",
    cover: "./images/Mohsen-Chavoshi-Ya-Mola.jpg",
    audio: new Audio("./musices/Mohsen Chavoshi - Ya Mola (128).mp3"),
  },
  {
    name: "محسن یگانه - بهت قول میدم",
    cover: "./images/Mohsen-Yeganeh-Behet-Ghol-Midam.jpg",
    audio: new Audio("./musices/Mohsen Yeganeh - Behet Ghol Midam (128).mp3"),
  },
  {
    name: "رامین کارمی - دریا دریا",
    cover: "./images/Ramin-Karami-Darya-Darya-Music-fa.com_.jpg",
    audio: new Audio("./musices/Ramin Karami - Darya (320).mp3"),
  },
];

// المنت‌های DOM
let range = document.querySelector("#music-time");
let playBtn = document.querySelector("#play-btn");
let preBtn = document.querySelector("#pre-btn");
let nextBtn = document.querySelector("#next-btn");
let musicCover = document.querySelector("#music-cover");
let musicName = document.querySelector("#music-name");

// متغیرهای حالت
let currentMusic = 0;
let audio = musices[currentMusic].audio;
let isPlaying = false;

// مقداردهی اولیه
initializePlayer();

// تابع مقداردهی اولیه پلیر
function initializePlayer() {
  // نمایش اطلاعات موزیک فعلی
  updateMusicInfo();
  
  // تنظیم event listenerها
  setupAudioEvents();
  
  // تنظیم event listener برای دکمه‌ها
  playBtn.addEventListener("click", togglePlayPause);
  nextBtn.addEventListener("click", playNext);
  preBtn.addEventListener("click", playPrevious);
  
  // تنظیم event listener برای range
  range.addEventListener("input", () => {
    audio.currentTime = range.value;
  });
}

// تابع به‌روزرسانی اطلاعات نمایشی
function updateMusicInfo() {
  musicName.textContent = musices[currentMusic].name;
  musicCover.src = musices[currentMusic].cover;
  
  // اضافه کردن کلاس animation به عکس
  musicCover.classList.add("playing");
  
  // اگر موزیک در حال پخش نباشد، animation را متوقف کن
  if (!isPlaying) {
    musicCover.style.animationPlayState = "paused";
  } else {
    musicCover.style.animationPlayState = "running";
  }
}

// تابع تنظیم event listenerهای audio
function setupAudioEvents() {
  // حذف event listenerهای قبلی (اگر وجود دارند)
  audio.removeEventListener("loadedmetadata", setDuration);
  audio.removeEventListener("timeupdate", updateTime);
  audio.removeEventListener("ended", onMusicEnd);
  
  // تنظیم event listenerهای جدید
  audio.addEventListener("loadedmetadata", setDuration);
  audio.addEventListener("timeupdate", updateTime);
  audio.addEventListener("ended", onMusicEnd);
}

// تابع تنظیم مدت زمان
function setDuration() {
  range.max = audio.duration;
  range.value = 0;
}

// تابع به‌روزرسانی زمان
function updateTime() {
  range.value = audio.currentTime;
}

// تابع تغییر وضعیت پخش/توقف
function togglePlayPause() {
  if (audio.paused) {
    playMusic();
  } else {
    pauseMusic();
  }
}

// تابع پخش موزیک
function playMusic() {
  audio.play()
    .then(() => {
      isPlaying = true;
      playBtn.classList.replace("fa-play", "fa-pause");
      musicCover.style.animationPlayState = "running";
    })
    .catch(error => {
      console.error("خطا در پخش موزیک:", error);
      alert("خطا در پخش موزیک. لطفا بررسی کنید که فایل موزیک وجود داشته باشد.");
    });
}

// تابع توقف موزیک
function pauseMusic() {
  audio.pause();
  isPlaying = false;
  playBtn.classList.replace("fa-pause", "fa-play");
  musicCover.style.animationPlayState = "paused";
}

// تابع پخش موزیک بعدی
function playNext() {
  changeMusic("next");
}

// تابع پخش موزیک قبلی
function playPrevious() {
  changeMusic("pre");
}

// تابع تغییر موزیک
function changeMusic(direction) {
  // توقف موزیک فعلی
  pauseMusic();
  
  // ریست کردن زمان
  audio.currentTime = 0;
  range.value = 0;
  
  // تغییر index موزیک
  if (direction === "next") {
    currentMusic = (currentMusic + 1) % musices.length;
  } else { // direction === "pre"
    currentMusic = (currentMusic - 1 + musices.length) % musices.length;
  }
  
  // به‌روزرسانی آبجکت audio
  audio = musices[currentMusic].audio;
  
  // به‌روزرسانی اطلاعات نمایشی
  updateMusicInfo();
  
  // تنظیم event listenerهای جدید
  setupAudioEvents();
  
  // پخش خودکار موزیک جدید (اختیاری)
  // playMusic(); // اگر می‌خواهید بعد از تغییر خودکار پخش شود
}

// تابعی که وقتی موزیک تمام شد اجرا می‌شود
function onMusicEnd() {
  pauseMusic();
  // پخش موزیک بعدی به صورت خودکار (اختیاری)
  // setTimeout(playNext, 1000);
}

// اضافه کردن event listener برای زمانی که صفحه لود شد
window.addEventListener('DOMContentLoaded', () => {
  // بارگذاری اولیه metadata
  audio.load();
});
