let canvas = window.document.getElementsByTagName("canvas")[0];
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let c = canvas.getContext("2d");
class Ball {
  constructor() {
    this.r = 20;
    this.x = randomNumber(0 +this. r, window.innerWidth - this.r);
    this.y = randomNumber(0 + this.r, window.innerHeight - this.r);
    this.vX = randomNumber(0, 10) - 1;
    this.vY = randomNumber(0, 10) - 1;
    this.draw();
  }
  draw() {
    c.beginPath();
    c.arc(this.x, this.y, this.r, 0, 2 * Math.PI);
    c.fillStyle = "red";
    c.fill();
  }
  update() {
    if (this.x + this.r > window.innerWidth || this.x - this.r < 0) {
      this.vX = -this.vX;
    }
    if (this.y + this.r > window.innerHeight || this.y - this.r < 0) {
      this.vY = -this.vY;
    }
    this.x += this.vX;
    this.y += this.vY;
    this.draw();
  }
}
let ball1 = new Ball();
function anime() {
  c.clearRect(0, 0, window.innerWidth, window.innerHeight);

  ball1.update();
  requestAnimationFrame(anime);
}
anime();
function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1));
}
