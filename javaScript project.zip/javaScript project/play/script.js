let canvas = window.document.getElementsByTagName("canvas")[0];
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let c = canvas.getContext("2d");
this.screen = {
  width: window.innerWidth,
  height: window.innerHeight,
};
this.mouse = {
  x: screen.width / 2,
  y: screen.height / 2,
};
class Ball {
  constructor(x, y, dx, dy, r, color) {
    this.r = r || 20;
    this.x = x || randomNumber(0 + this.r, window.innerWidth - this.r);
    this.y = y || randomNumber(0 + this.r, window.innerHeight - this.r);
    this.dx = dx || randomNumber(0, 10) - 1;
    this.dy = dy || randomNumber(0, 10) - 1;
    this.color = color || "red";
    this.fraction = 0.8;
    this.gravity = 1;
    this.draw();
  }
  draw() {
    c.beginPath();
    c.arc(this.x, this.y, this.r, 0, 2 * Math.PI);
    c.fillStyle = rundomColor();
    c.fill();
  }
  update() {
    //gravity
    //   if (this.y + this.r + this.dy >= screen.height) {
    //     this.dy = -this.dy * this.fraction;
    //     this.dx = -this.dx * this.fraction;
    //   } else {
    //     this.dy += this.gravity;
    //   }
    //   if (
    //     this.x + this.r + this.dx >= screen.width ||
    //     this.x + this.r + this.dx <= 0
    //   ) {
    //     this.x = -this.dx;
    //   }
    //   this.y += this.dy;
    //
    //   this.dx = -this.dx;
    //
    //   this.draw();

    if (this.x + this.r > screen.width || this.x - this.r < 0) {
      this.dx = -this.dx;
    }
    if (this.y + this.r > window.innerHeight || this.y - this.r < 0) {
      this.dy = -this.dy;
    }
    this.x += this.dx;
    this.y += this.dy;
    this.draw();
  }
}
class Canvas {
  constructor() {
    this.balls = [];
    for (let i = 0; i < 20; i++) {
      this.balls.push(new Ball());
    }
  }
  anime() {
    c.clearRect(0, 0, window.innerWidth, window.innerHeight);
    this.balls.forEach((bull) => {
      return bull.update();
    });
    requestAnimationFrame(this.anime.bind(this));
  }
}
let myCanvas = new Canvas();
myCanvas.anime();
addEventListener("click", function (e) {
  myCanvas.balls.push(new Ball(e.clientX, e.clientY));
});
addEventListener("mousemove", function (e) {
  mouse.x = e.clientX;
  mouse.y = e.clientY;
});
addEventListener("resize", function (e) {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});
function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}
function rundomColor() {
  let number = randomNumber(0, 11);
  let colorBall = "";
  if (0 < number < 1) {
    colorBall = "blue";
  } else if (2 < number < 3) {
    colorBall = "green";
  } else if (3 < number < 4) {
    colorBall = "aquamarine";
  } else if (5 < number < 6) {
    colorBall = "red";
  } else if (6 < number < 7) {
    colorBall = "yellow";
  } else if (7 < number < 8) {
    colorBall = "blueviolet";
  } else if (8 < number < 9) {
    colorBall = "white";
  } else if (9 < number < 10) {
    colorBall = "chartreuse";
  } else if (4 < number < 5) {
    colorBall = "darkcyan";
  } else {
    colorBall = "#333";
  }
  return colorBall;
}
