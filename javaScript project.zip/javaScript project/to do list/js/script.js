let list = window.document.getElementById("to-do-list");
let addBtn = window.document.querySelector(".add-form button");
let searchInput = window.document.querySelector("#search-form input");
let searchBtn = window.document.querySelector("#search-form button");
let addInput = window.document.querySelector(".add-form input");

// جلوگیری از submit شدن فرم جستجو
document.querySelector("#search-form").addEventListener("submit", (e) => {
  e.preventDefault();
});

// حذف آیتم از لیست
list.addEventListener("click", (e) => {
  // اصلاح: بررسی delete-btn یا delete-btn1
  if (e.target.nodeName == "SPAN" && 
      (e.target.className.includes("delete-btn") || e.target.className.includes("delete-btn1"))) {
    e.target.parentNode.remove();
    
    // بررسی اگر لیست خالی شد
    checkIfListIsEmpty();
  }
});

// اضافه کردن آیتم جدید
addBtn.addEventListener("click", (e) => {
  e.preventDefault();
  
  if (!addInput.value.trim()) {
    alert("لطفاً یک کار وارد کنید!");
    return;
  }

  // حذف پیام "لیست خالی" اگر وجود دارد
  const emptyMessage = document.getElementById("empty-message");
  if (emptyMessage) {
    emptyMessage.remove();
  }
  
  // اضافه کردن آیتم جدید
  list.append(createListItem(addInput.value));
  
  // خالی کردن input
  addInput.value = "";
});

// تابع ایجاد آیتم لیست (مطابق با ساختار HTML شما)
function createListItem(itemValue) {
  let item = window.document.createElement("li");
  let title = window.document.createElement("span");
  let btnSuccess = window.document.createElement("span");
  let btnDanger = window.document.createElement("span");
  
  // اصلاح: استفاده از کلاس‌های یکسان با HTML
  item.className = "to-do-item m-3";
  title.innerText = itemValue;
  title.className = "title";
  
  btnSuccess.className = "delete-btn btn btn-success m-2";
  btnSuccess.innerText = "کار با موفقیت انجام شد";
  
  btnDanger.className = "delete-btn btn btn-danger";
  btnDanger.innerText = "کار با شکست انجام شد";
  
  item.appendChild(title);
  item.appendChild(btnSuccess);
  item.appendChild(btnDanger);
  
  return item;
}

// تابع جستجو با input
searchInput.addEventListener("input", (e) => {
  performSearch(e.target.value);
});

// تابع جستجو با دکمه
searchBtn.addEventListener("click", (e) => {
  e.preventDefault();
  performSearch(searchInput.value);
});

// تابع اصلی جستجو
function performSearch(searchValue) {
  Array.from(list.children).forEach((element) => {
    // رد کردن پیام "لیست خالی"
    if (element.id === "empty-message") {
      element.style.display = "none";
      return;
    }
    
    const titleElement = element.querySelector(".title");
    if (titleElement) {
      const itemText = titleElement.innerText.toLowerCase();
      if (itemText.includes(searchValue.toLowerCase())) {
        element.style.display = "flex";
      } else {
        element.style.display = "none";
      }
    }
  });
}

// تابع بررسی خالی بودن لیست
function checkIfListIsEmpty() {
  // تعداد آیتم‌های واقعی (غیر از پیام خالی و با کلاس to-do-item)
  const realItems = Array.from(list.children).filter(item => 
    item.id !== "empty-message" && item.classList.contains("to-do-item")
  );
  
  if (realItems.length === 0) {
    // اگر قبلاً پیام وجود دارد، دوباره نساز
    if (!document.getElementById("empty-message")) {
      let emptyMessage = window.document.createElement("h3");
      emptyMessage.style.textAlign = "center";
      emptyMessage.style.color = "white";
      emptyMessage.style.padding = "20px";
      emptyMessage.innerText = "تبریک می‌گویم! شما کارهایتان را تمام کرده‌اید";
      emptyMessage.id = "empty-message";
      list.appendChild(emptyMessage);
    }
  }
}

// بررسی اولیه هنگام بارگذاری صفحه
checkIfListIsEmpty();
