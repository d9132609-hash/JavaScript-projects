window.addEventListener("hashchange", () => {
  router();
});
function router() {
    switch (location.hash) {
        case "":
            render({title:" HOME",color:"blue",href:"#home"})
            break;
        case "#home":
            render({title:" HOME",color:"blue",href:"#home"})
            break;
        case "#search":
            render({title:" SEARCH",color:"yellow",href:"#search"})
            break;
        case "#profile":
            render({title:" PROFILE",color:"aqua",href:"#profile"})
            break;
        case "#heart":
            render({title:" HEART",color:"red",href:"#heart"})
            break;    
        default:
            break;
    }
}
function render(data) {
    window.document.querySelector("h1").innerText=data.title;
    window.document.querySelector("main").style.backgroundColor=data.color;
    window.document.querySelectorAll("a").forEach((element)=>{
        if (element.href.includes(data.href)) {
            element.style.color="black"
            
        } else {
            element.style.color="#666"
        }
    })

}
